# QA-Ecommerce-Testing
A structured QA testing project demonstrating manual testing, API validation, defect tracking, and test documentation for an e-commerce web application using industry-standard practices.
